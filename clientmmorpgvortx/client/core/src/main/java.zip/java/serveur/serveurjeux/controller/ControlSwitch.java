package serveur.serveurjeux.controller;

import serveur.serveurjeux.DTO.Message;
import serveur.serveurjeux.DTO.typeReponse.ReponseDemandeLogin;
import serveur.serveurjeux.DTO.typeReponse.ReponseUUID;

import java.io.IOException;
import java.io.PrintWriter;

public class ControlSwitch {

    public static void lecture(int code, Message message) throws IOException {
        switch (code) {
            case 1: //message de ping
                break;
            case 2: //reception de UUID
                System.out.println("requête de UUID");
                ActionReseau.receptionUUID((ReponseUUID) message);
                break;
            case 3: //reception du pseudo ainsi que le mdp
                System.out.println("reception du login");
                ActionReseau.receptionLogin((ReponseDemandeLogin) message);
            default:
                System.out.println("Erreur lecture");
                break;
        }
    }


}
