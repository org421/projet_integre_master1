package serveur.serveurjeux;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.math.Vector2;
import serveur.serveurjeux.informationClient.Reseau;

import java.io.IOException;
import java.io.PrintWriter;

public class ReceptionToucheEtSouris {

    //--------------------------------------------------------//
    //
    //        Fonction renvoyant les touches pressées
    //
    //--------------------------------------------------------//
    public static void receptionToucheAppuyer() throws IOException {
        if(Reseau.socket != null) {
            PrintWriter writer = new PrintWriter(Reseau.socket.getOutputStream(), true);
            if (Gdx.input.isKeyJustPressed(Input.Keys.W)) {
                System.out.println("Z");
                writer.println("2");
            }
            if (Gdx.input.isKeyJustPressed(Input.Keys.A)) {
                System.out.println("Q");
                writer.println("2");
            }
            if (Gdx.input.isKeyJustPressed(Input.Keys.S)) {
                System.out.println("S");
                writer.println("2");
            }
            if (Gdx.input.isKeyJustPressed(Input.Keys.D)) {
                System.out.println("D");
                writer.println("2");
            }
            if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) {
                System.out.println("ESPACE");
            }
        }
    }

    //--------------------------------------------------------//
    //
    //    Fonction renvoyant la position de la souris
    //    lors d un clic gauche ou droit
    //    Si besoin elle est faite
    //
    //--------------------------------------------------------//
    public static void receptionClicSouris() {
        if (Gdx.input.isButtonJustPressed(Input.Buttons.LEFT)) {
            int mouseX = Gdx.input.getX();
            int mouseY = Gdx.graphics.getHeight() - Gdx.input.getY(); // Inversion de l'axe Y
            System.out.println("(Clique gauche, " + mouseX + ", " + mouseY + ")");
        }
        if (Gdx.input.isButtonJustPressed(Input.Buttons.RIGHT)) {
            int mouseX = Gdx.input.getX();
            int mouseY = Gdx.graphics.getHeight() - Gdx.input.getY(); // Inversion de l'axe Y
            System.out.println("(Clique droit, " + mouseX + ", " + mouseY + ")");
        }
    }

    //--------------------------------------------------------//
    //
    //    Fonction renvoyant la position de la souris
    //    et le vecteur de direction par rapport au centre de
    //              de la fenetres
    //
    //--------------------------------------------------------//
    public static void receptionClicSourisAvecDirection() {
        // le milieu de la fenetre
        int centerX = Gdx.graphics.getWidth() / 2;
        int centerY = Gdx.graphics.getHeight() / 2;

        if (Gdx.input.isButtonJustPressed(Input.Buttons.LEFT)) {
            int mouseX = Gdx.input.getX();
            int mouseY = Gdx.graphics.getHeight() - Gdx.input.getY(); // Inversion de l'axe Y

            // vecteur de la direction de la souris
            Vector2 direction = new Vector2(mouseX - centerX, mouseY - centerY);

            System.out.println("(Clique gauche, " + mouseX + ", " + mouseY + ")");
            System.out.println("Vecteur direction : " + direction);
        }

        if (Gdx.input.isButtonJustPressed(Input.Buttons.RIGHT)) {
            int mouseX = Gdx.input.getX();
            int mouseY = Gdx.graphics.getHeight() - Gdx.input.getY(); // Inversion de l'axe Y

            // vecteur de la direction de la souris
            Vector2 direction = new Vector2(mouseX - centerX, mouseY - centerY);

            System.out.println("(Clique droit, " + mouseX + ", " + mouseY + ")");
            System.out.println("Vecteur direction : " + direction);
        }
    }
}
