package serveur.serveurjeux.DTO.typeMessage;


import java.io.Serializable;

public class deplacement implements Serializable {
    int direction;
    int idCode;


    public int getDirection() {
        return direction;
    }

    public void setDirection(int direction) {
        this.direction = direction;
    }

    public int getIdCode() {
        return idCode;
    }

    public void setIdCode(int idCode) {
        this.idCode = idCode;
    }



}
