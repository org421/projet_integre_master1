package serveur.serveurjeux;

import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

import java.io.IOException;

public class FirstScreen implements Screen {
    private SpriteBatch batch;
    private Animation<TextureRegion> eauAnimation;
    private Texture[] textures;
    private float stateTime = 0;

    @Override
    public void show() {
        batch = new SpriteBatch();

        textures = new Texture[10];
        TextureRegion[] eauAnimationFrame = new TextureRegion[10];
        for (int i = 0; i < 10; i++) {
            textures[i] = new Texture("eau/eau_frame_" + (i + 1) + ".png");
            eauAnimationFrame[i] = new TextureRegion(textures[i]);
        }

        eauAnimation = new Animation<>(0.1f, eauAnimationFrame);
    }



    //--------------------------------------------------------//
    //
    //        J'explique pour les gens qui vont relire
    //        render c'est une fonction qui se lance en boucle
    //        donc les fonction de reception de touche
    //        sont lus en permanance ce qui permettrons
    //        d envoyer au serveur les touche h24
    //
    //--------------------------------------------------------//
    @Override
    public void render(float delta) {
        stateTime += delta;

        try {
            ReceptionToucheEtSouris.receptionToucheAppuyer();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        ReceptionToucheEtSouris.receptionClicSourisAvecDirection();

        TextureRegion currentEau = eauAnimation.getKeyFrame(stateTime, true);

        batch.begin();
        batch.draw(currentEau, -30 * 32, -30 * 32, 5000, 5000);
        batch.end();
    }

    @Override
    public void resize(int width, int height) {}

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}

    @Override
    public void dispose() {
        batch.dispose();
        for (Texture texture : textures) {
            texture.dispose();
        }
    }
}
