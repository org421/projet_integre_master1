package serveur.serveurjeux.controller;

import serveur.serveurjeux.DTO.Envoie;
import serveur.serveurjeux.DTO.typeMessage.DemandeLogin;
import serveur.serveurjeux.DTO.typeReponse.ReponseDemandeLogin;
import serveur.serveurjeux.DTO.typeReponse.ReponseUUID;
import serveur.serveurjeux.FirstScreen;
import serveur.serveurjeux.informationClient.Reseau;

import java.io.IOException;

public class ActionReseau {

    public static void receptionUUID(ReponseUUID reponse) {
        Reseau.UUID = reponse.getUuid();
        System.out.println(Reseau.UUID);
    }

    public static void EnvoieLogin(String pseudo, String password) throws IOException {

        System.out.println(pseudo);
        System.out.println(password);


        Envoie envoie = new Envoie(Reseau.address,Reseau.UUID);
        DemandeLogin demandeLogin = new DemandeLogin();
        demandeLogin.pseudo = pseudo;
        demandeLogin.mdp = password;




        envoie.ajouterMessage(demandeLogin);
        Reseau.writer.writeObject(envoie);
        Reseau.writer.flush();
    }

    public static void receptionLogin(ReponseDemandeLogin reponse) {
        System.out.println(reponse.valide);
        if (reponse.valide){
//            FirstScreen firstScreen = new FirstScreen();

        }
    }
}
