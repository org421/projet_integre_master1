package serveur.serveurjeux.DTO;

public interface Message {
    int getType();
}
